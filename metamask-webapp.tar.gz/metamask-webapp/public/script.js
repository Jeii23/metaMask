// public/script.js

/**
 * Simple helper that turns any ASCII / UTF‑8 string into a hex string
 * prefixed with 0x so it can be used as EVM calldata.
 */
function asciiToHex(str) {
  return (
    "0x" +
    Array.from(new TextEncoder().encode(str))
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("")
  );
}

// Ask MetaMask for account access if we haven't already.
async function ensureAccountAccess() {
  if (!window.ethereum) {
    alert("MetaMask no està instal·lat!");
    throw new Error("MetaMask not installed");
  }
  try {
    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
    console.log("Comptes disponibles:", accounts);
    return accounts;
  } catch (error) {
    console.error("Error al sol·licitar accés als comptes:", error);
    throw error;
  }
}

// Send the transaction to MetaMask to be signed & broadcast.
async function sendUnsignedTransaction(txObject) {
  try {
    const txHash = await window.ethereum.request({
      method: "eth_sendTransaction",
      params: [txObject],
    });
    document.getElementById("status").innerText = "Transacció enviada! Hash: " + txHash;
    console.log("Hash de la transacció:", txHash);
  } catch (error) {
    document.getElementById("status").innerText = "Error en enviar la transacció: " + error.message;
    console.error("Error en enviar la transacció:", error);
  }
}

// Handle button click.
document.getElementById("sendTxButton").addEventListener("click", async () => {
  try {
    await ensureAccountAccess();

    const txText = document.getElementById("txInput").value;
    if (!txText) {
      alert("Introdueix el JSON de la transacció!");
      return;
    }

    let txObject;
    try {
      txObject = JSON.parse(txText);
    } catch (parseError) {
      alert("El JSON de la transacció no és vàlid.");
      return;
    }

    // 🔹 NEW: Accept plain‑text `data` and convert to hex‑encoded calldata.
    if (typeof txObject.data === "string" && txObject.data.trim() !== "") {
      if (!txObject.data.startsWith("0x")) {
        const ascii = txObject.data.trim();
        const hexData = asciiToHex(ascii);
        console.log(`Convertim 'data' ASCII → hex: '${ascii}' ⇒ '${hexData}'`);
        txObject.data = hexData;
      }
    }

    console.log("Transacció a enviar:", txObject);
    await sendUnsignedTransaction(txObject);
  } catch (error) {
    console.error("Error en el procés:", error);
  }
});
